/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Tienda.controller;

import com.Tienda.entity.Pais;
import com.Tienda.entity.Persona;
import com.Tienda.service.IPaisService;
import com.Tienda.service.IPersonaService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
/**
 *
 * @author manfr
 */
@Controller
public class PersonaController {
    @Autowired
    private IPaisService paisService;
    
     @Autowired
    private IPersonaService personaService;
    
    
    //Para ver las tablas, jalar la info de mysql, leerlo
    @GetMapping("/persona")
    //con este model le pasamos informacion a mi html de personas
    public String index (Model model){
        List<Persona> listaPersona = personaService.getAllPersona();
        model.addAttribute("titulo", "Tabla Personas");
        model.addAttribute("personas", listaPersona);
        //devolviendo un html de personas
        return "personas";
    }
    //El get mapping es el URL
     @GetMapping("/personaN")
    public String crearPersona (Model model){
        List<Pais> listaPaises = paisService.listCountry();
        model.addAttribute("persona", new Persona()); //le vamos a insertar un objecto
        model.addAttribute("paises", listaPaises);
        //Aqui tenemos que ponerle igual al html que vamos a utilizar
        return "crear";
    }
    //como no queremos obtener nada, no es un getmapping
      @PostMapping("/save")
      //Aqui lo que vamos a hacer es enviarle del html , informacion al metodo
    public String guardarPersona (@ModelAttribute Persona persona){// siempre pasan el objecto
        personaService.savePersona(persona);// aqui ya lo estamos guardamdo en la base de datos
        
        return "redirect:/persona";// con este redirect nos va a mandar a la lista que ya tenemos, mostrando ya las personas
    }// mostrando el html personas, confirmando que si se guardo
    
    @GetMapping("/editPersona/{id}")//Como para modificar una persona ocupamos un id, tonces dentro del mismo url se lo vamos a pasar, para poder buscarlo en la base de datos
    public String editarPersona (@PathVariable("id") long idPersona ,Model model){// el id persona es log, porque en la clase persona pusimos el id de variable LONG
        //PathVariable es cuando se va a modificar              este model es para pasarle la informacion
        
        //Aqui llamamos a la persona que queremos editar
        Persona persona = (Persona) personaService.getPersonaById(idPersona);//le pasamos el id persona que pedimos en el parametro, lo pedimos en el url
        List<Pais> listaPaises = paisService.listCountry();// como queremos editar el pais, lo llamamos
       // model.addAttribute("persona", new Persona());//Como ya tenemos el objecto creado no le ponemos new Persona  
        model.addAttribute("persona", persona);
        model.addAttribute("paises", listaPaises);
        //cuando vamos a editar una persona, igualmente hay que llenar el formulario que se lleno cuando se estaban creando
        //por eso se returna crear y no "editar", pero si se hiciera asi estaria igualmente bien
        return "crear";
    }
    @GetMapping("/delete/{id}")//                                        
     public String eliminarPersona (@PathVariable("id") long idPersona ){// el id persona es log, porque en la clase persona pusimos el id de variable LONG
        //PathVariable es cuando se va a modificar             como no ocupamos pasar nada le quitamos el model
        
        //Aqui llamamos a la persona que queremos editar
        personaService.delete(idPersona);//le pasamos el id persona que pedimos en el parametro, lo pedimos en el url
       
      
        return "redirect:/persona";
    }
    
}


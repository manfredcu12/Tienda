/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Tienda.entity;

/**
 *
 * @author manfr
 */
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "paises")
public class Pais implements Serializable{
    @Id
    //El input que pusimos en el html, que dice id
    //el va a reconocer esto y va a detectar que es auto incremental
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //estos atributos coinciden con la tabla de "paises" en la base de datos
    private long id;
    private String pais;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }
    
    
    
    
    
    
}

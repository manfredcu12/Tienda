/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.Tienda.service;

import com.Tienda.entity.Persona;
import java.util.List;



//este no lleva @ que llevan los otros
public interface IPersonaService {
    //Esta lista va a guardar objectos de tipo persona
    public List<Persona> getAllPersona();
    
    //vamos a obtener a una persona de la base de datos con el id
    public Persona getPersonaById ( long id);
    //guardar una nueva fila en la base de datos
    public void savePersona(Persona id);
    //elimina una fila de la base de datos
    public void delete(long id);
    
    public Persona findByNombre( String nombre);
}
/**
 *
 * @author manfr
 */

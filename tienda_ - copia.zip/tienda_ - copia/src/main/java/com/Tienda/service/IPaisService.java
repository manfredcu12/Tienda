/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.Tienda.service;

import com.Tienda.entity.Pais;
import java.util.List;
/**
 *
 * @author manfr
 */
//este no lleva @ que llevan los otros
public interface IPaisService {
    //aqui estan todos los paises
    public List<Pais> listCountry();
}

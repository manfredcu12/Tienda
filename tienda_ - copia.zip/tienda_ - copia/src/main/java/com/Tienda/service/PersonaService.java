/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Tienda.service;

import com.Tienda.entity.Pais;
import com.Tienda.entity.Persona;
import com.Tienda.repository.PersonaRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service

public class PersonaService implements IPersonaService{
   //aqui lo que se hace es llamar mediante implements a los metodos creados en la interface 
    
    //Aqui le damos click al bombillo rojo y le damos insertar todas las clases abstractas
    //con esto ya van a aparecer los metedos del javagene que hicimos en la interface
   
    @Autowired
    private PersonaRepository personaRepository;
    //Como personaRepository es el que se conecta en la base de datos, nos interesa llamarlo aca
    
    @Override
    public List<Persona> getAllPersona() {
      return (List<Persona>)personaRepository.findAll();
      //Con este se devuelven a todos los datos de la tabla(persona)
    }

    @Override
    public Persona getPersonaById(long id) {
        return personaRepository.findById(id).orElse(null);
    }

    @Override
    public void savePersona(Persona persona) {
    personaRepository.save(persona);
    }

    @Override
    public void delete(long id) {
       personaRepository.deleteById(id);
    }
   //El override lo que hace es sobreescribir los metodos que implementamos en la interfaz
    @Override
    public Persona findByNombre(String nombre){
        return personaRepository.findByNombre(nombre);
    }
    
   
}

